# Banking_App
It is an android application that deploys a basic banking system. It facilitates the transfer of money between the users while keeping a record of all the transactions thus performed. 
It is built using Java and SQLite.

https://user-images.githubusercontent.com/68818818/111902645-7a690e00-8a64-11eb-98a1-348b457fce61.mp4

