package com.example.your_sf_banking_app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String dbname = "Bankdb";
    private static final int version= 1;

    public DatabaseHelper(Context context){
        super(context, dbname , null, version);
    }
    
    @Override
    public void onCreate(SQLiteDatabase db) {
       //table creation
       String sql = "CREATE TABLE USER_DETAILS (_id INTEGER , NAME TEXT, EMAIL VARCHAR PRIMARY KEY,BALANCE INTEGER,PHONENUMBER TEXT,ACCOUNT VARCHAR)";
       db.execSQL(sql);
       String sql_tr = "CREATE TABLE TRANSACT_DETAILS (transact_id INTEGER , FROMNAME TEXT, TONAME TEXT, AMOUNT INTEGER, STATUS TEXT)";
       db.execSQL(sql_tr);
       //to insert data
        insertData("Juhi","juhi@gmail.com",100000,"978543219","XXXXXXXXXXXX05",db);
        insertData("PriyaRajput","priya@gmail.com",34000,"8789543260","XXXXXXXXXXXX35",db);
        insertData("SaloniGaur","salonigaur@gmail.com",50000,"9675421765 ","XXXXXXXXXXXX97",db);
        insertData("RajPanchal","raj@gmail.com",56000,"9846538273","XXXXXXXXXXXX96",db);
        insertData("Kshitij ","kshitijterna@gmail.com",7000,"925737838","XXXXXXXXXXXX95",db);
        insertData("VaibhavSingh","vaibhav2020@gmail.com",50000,"9947352698","XXXXXXXXXXXX94",db);
        insertData("AishaSingh","aisha2000@gmail.com",90000,"9395653957","XXXXXXXXXXXX93",db);
        insertData("SimranMalhotra","simran20@gmail.com",87000,"9784632190","XXXXXXXXXXXX53",db);
        insertData("ShubhamB","bshubu@gmail.com",20000,"93998473628","XXXXXXXXXXXX76",db);
        insertData("PranavDubey","d@gmail.com",70000,"9746514587","XXXXXXXXXXXXXX07",db);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS USER_DETAILS");
        db.execSQL("DROP TABLE IF EXISTS TRANSACT_DETAILS");
        onCreate(db);
    }
    public Cursor ReadAllData(){
        SQLiteDatabase db =getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from USER_DETAILS",null);
        return cursor;
    }
    public Cursor readParticularData(String Email){
        SQLiteDatabase db = this.getWritableDatabase();
        String select = "select * from USER_DETAILS where Email = '"+Email + "'";
        Cursor cursor = db.rawQuery(select,null);
        return cursor;
    }

    public Cursor ReadSelectedData(String Email){
        SQLiteDatabase db = getWritableDatabase();
        String select ="select * from USER_DETAILS where email <> '"+Email + "'";
        Cursor c = db.rawQuery(select,null);
        return c;
    }
    public void UpdateAmount(String Email,String amount){
        SQLiteDatabase db =this.getWritableDatabase();
        String select="UPDATE USER_DETAILS set BALANCE = '"+ amount +"' where Email = '"+Email+"'";
        db.execSQL(select);
    }

    private void insertData(String name, String email, int balance,String phoneNumber,String account,SQLiteDatabase database){
        ContentValues values= new ContentValues();
        values.put("NAME",name);
        values.put("EMAIL",email);
        values.put("PHONENUMBER",phoneNumber);
        values.put("ACCOUNT",account);
        values.put("BALANCE",balance);
        database.insert("USER_DETAILS",null,values);
    }
    public void insertTransferData(String from_name, String to_name, int amount, String Status){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values= new ContentValues();
        values.put("FROMNAME",from_name);
        values.put("TONAME",to_name);
        values.put("AMOUNT",amount);
        values.put("STATUS",Status);
        database.insert("TRANSACT_DETAILS",null,values);
    }


    public Cursor Read_Transfer_amount_Data() {
        SQLiteDatabase db = this.getWritableDatabase();
        String select = "select * from TRANSACT_DETAILS";
        Cursor cursor = db.rawQuery(select,null);
        return cursor;
    }
}
